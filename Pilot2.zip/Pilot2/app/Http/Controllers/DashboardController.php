<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function check($request)
    {
        if(LoginController.authenticate())
        return view('dashboard');
        else
            return view('welcome');
    }

    public function index()
    {
        return view('dashboard');
    }
}
