<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                <?php 
                    $all_article = DB::table('articles')->where('user', Auth::user()->id)->get();
                ?>
                <?php $__currentLoopData = $all_article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $art): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <h1> <?php echo e($art->title); ?> </h1>
                    <label> <?php echo e($art->para); ?> </label> <br>
                    <?php
                        $user = DB::table('users')->where('id', $art->user)->first();
                    ?>
                    <label> USER:  <?php echo e(Auth::user()->name); ?> </label>
                    <br>
                    <label> Published on: <?php echo e($art->published); ?>  </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>